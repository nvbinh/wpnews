<?php

/**
 * TGM Init Class
 */
include_once ('class-tgm-plugin-activation.php');

function awaken_recommended_plugins() {

    $plugins = array(
        array(
            'name'      => 'Redux Framework',
            'slug'      => 'redux-framework',
            'required'  => false,
        ),        
    );

    $config = array(
        'domain'            => 'awaken',           // Text domain - likely want to be the same as your theme.
        'default_path'      => '',                          // Default absolute path to pre-packaged plugins
        'parent_menu_slug'  => 'plugins.php',               // Default parent menu slug
        'parent_url_slug'   => 'plugins.php',               // Default parent URL slug
        'menu'              => 'install-required-plugins',  // Menu slug
        'has_notices'       => true,                        // Show admin notices or not
        'is_automatic'      => true,                        // Automatically activate plugins after installation or not
    );

    tgmpa( $plugins, $config );

}
add_action( 'tgmpa_register', 'awaken_recommended_plugins' );